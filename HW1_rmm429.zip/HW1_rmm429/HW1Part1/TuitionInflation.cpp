/*
Program: TuitionInflation.cpp
Purpose: To calculate the tution for each year of a five year collge and the total tuition amount after 5 years, given the tuiton of the first year and the percent increase.
Author: Ricky Mangerie
Last Date Revised: 1/19/2016
Contact: rmm429@drexel.edu
*/

//preprocessor
#include <iostream>
#include <iomanip> // used when formatting the output
using namespace std;

int main()
{
	//Prompting the user to input an intial tuition amount of type Integer and storing the tuition amount into memory
	cout << "Please enter the initial tuition amount (please enter an Integer): $"; 
	long tuitionFirstYear;
	cin >> tuitionFirstYear;

	//Declaring a constant for the amount of cents per dollar and converting the tuition amount from dollars into cents
	const int CENTS_PER_DOLLAR = 100;
	long tuitionFirstYearCents = tuitionFirstYear*CENTS_PER_DOLLAR;

	//Prompting the user to input the percentage increase for tuition of type Integer and storing the percentage amount into memory
	cout << "Please enter the percentage increase for tuition: ";
	double percentageIncrease;
	cin >> percentageIncrease;

	//Declaring a constant and a separate variable to change the inputted percentage type
	const double PERCENTAGE_LARGE_TO_SMALL = 100.0; //A constant that, when divided by the inputted percentage, will convert the percentage to a scaled rate
	double percentIncreaseTuition = (percentageIncrease / PERCENTAGE_LARGE_TO_SMALL) + 1; //Creates a variable that, when multiplied by the tuition, will give the value of the next year's tuition with the percent increase

	//Declaring the total tuition variable and constants for formatting
	long tuitionTotal = 0;
	const int NUMBER_OF_DECIMALS = 2; //A constant that, when used, will round the change value to 2 decimal places
	const char SPACE_FILL = '0'; //A constant that, when used, will fill a space in the change value to the character '0'
	const int WIDTH_OF_CHANGE = 2; //A constant that, when used, will set how wide the change value will be

	//Printing to the console the first year's tuition and adding it to the total tuition
	cout << "\nThe tuition for year one is $" << tuitionFirstYear << ".00." << endl << endl;
	tuitionTotal = tuitionTotal + tuitionFirstYearCents;

	//Calculating and outputting the second year's tuition and adding it to the total tuition
	long tuitionSecondYearCents = tuitionFirstYearCents*percentIncreaseTuition; //Calculating the second year's tuition in cents by multiplying it by the percent increase
	long tuitionSecondYearDollar = tuitionSecondYearCents / CENTS_PER_DOLLAR; //Calculating the dollar amount for the second year's tuition by dividing it by the cents per dollar constant
	long tuitionSecondYearChange = tuitionSecondYearCents % CENTS_PER_DOLLAR; //Calculating the change amount for the second year's tuition from the remainder of the dollar amount division
	cout << "The tuition for year two is $" << setfill(SPACE_FILL) << tuitionSecondYearDollar << "." 
		<< setw(WIDTH_OF_CHANGE) << setprecision(NUMBER_OF_DECIMALS) << tuitionSecondYearChange << "." 
		<< endl << endl; //Outputting the second year's tuition and using the formatting constants with their respective functions
	tuitionTotal = tuitionTotal + tuitionSecondYearCents;

	//Calculating and outputting the third year's tuition and adding it to the total tuition
	long tuitionThirdYearCents = tuitionSecondYearCents*percentIncreaseTuition; //Calculating the third year's tuition in cents by multiplying it by the percent increase
	long tuitionThirdYearDollar = tuitionThirdYearCents / CENTS_PER_DOLLAR; //Calculating the dollar amount for the third year's tuition by dividing it by the cents per dollar constant
	long tuitionThirdYearChange = tuitionThirdYearCents % CENTS_PER_DOLLAR; //Calculating the change amount for the third year's tuition from the remainder of the dollar amount division
		cout << "The tuition for year three is $" << setfill(SPACE_FILL) << tuitionThirdYearDollar 
		<< "." << setw(WIDTH_OF_CHANGE) << setprecision(NUMBER_OF_DECIMALS) << tuitionThirdYearChange << "." 
		<< endl << endl; //Outputting the third year's tuition and using the formatting constants with their respective functions
	tuitionTotal = tuitionTotal + tuitionThirdYearCents;

	//Calculating and outputting the fourth year's tuition and adding it to the total tuition
	long tuitionFourthYearCents = tuitionThirdYearCents*percentIncreaseTuition; //Calculating the fourth year's tuition in cents by multiplying it by the percent increase
	long tuitionFourthYearDollar = tuitionFourthYearCents / CENTS_PER_DOLLAR; //Calculating the dollar amount for the fourth year's tuition by dividing it by the cents per dollar constant
	long tuitionFourthYearChange = tuitionFourthYearCents % CENTS_PER_DOLLAR; //Calculating the change amount for the fourth year's tuition from the remainder of the dollar amount division
	cout << "The tuition for year four is $" << setfill(SPACE_FILL) << tuitionFourthYearDollar 
		<< "." << setw(WIDTH_OF_CHANGE) << setprecision(NUMBER_OF_DECIMALS) << tuitionFourthYearChange << "." 
		<< endl << endl; //Outputting the fourth year's tuition and using the formatting constants with their respective functions
	tuitionTotal = tuitionTotal + tuitionFourthYearCents;

	//Calculating and outputting the fifth year's tuition and adding it to the total tuition
	long tuitionFifthYearCents = tuitionFourthYearCents*percentIncreaseTuition; //Calculating the fifth year's tuition in cents by multiplying it by the percent increase
	long tuitionFifthYearDollar = tuitionFifthYearCents / CENTS_PER_DOLLAR; //Calculating the dollar amount for the fifth year's tuition by dividing it by the cents per dollar constant
	long tuitionFifthYearChange = tuitionFifthYearCents % CENTS_PER_DOLLAR; //Calculating the change amount for the fifth year's tuition from the remainder of the dollar amount division
	cout << "The tuition for year five is $" << setfill(SPACE_FILL) << tuitionFifthYearDollar 
		<< "." << setw(WIDTH_OF_CHANGE) << setprecision(NUMBER_OF_DECIMALS) << tuitionFifthYearChange << "." 
		<< endl << endl; //Outputting the fifth year's tuition and using the formatting constants with their respective functions
	tuitionTotal = tuitionTotal + tuitionFifthYearCents;

	//Calculating and outputting the total tuition
	long tuitionTotalDollar = tuitionTotal / CENTS_PER_DOLLAR; //Calculating the dollar amount for the total by dividing it by the cents per dollar constant
	long tuitionTotalChange = tuitionTotal % CENTS_PER_DOLLAR; //Calculating the change amount for the total tuition from the remainder of the dollar amount division
	cout << "The total sum of the tuitions for each of the five years is $" << setfill(SPACE_FILL) << tuitionTotalDollar 
		<< "." << setw(WIDTH_OF_CHANGE) << setprecision(NUMBER_OF_DECIMALS) << tuitionTotalChange << "." 
		<< endl << endl; //Outputting the total tuition and using the formatting constants with their respective functions

	//Inserting a statement to ensure the program does not exit earlier than it should
	int exitVariable;
	cout << "Type any key to exit: ";
	cin >> exitVariable;

	return 0;
}

