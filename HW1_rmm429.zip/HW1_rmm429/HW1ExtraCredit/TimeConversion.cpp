/*
Program: TimeConversion.cpp
Purpose: To convert the current time in Philadelphia in military time to military times in cities of other time zones
Name: Ricky Mangerie
Last Date Revised: 1/19/2016
Contact: rmm429@drexel.edu
*/

//preprocessor
#include <iostream>
#include <iomanip> //Used in formatting the output
using namespace std;

int main()
{
	//Declaring formatting constants
	const char TIME_SPACE_FILL = '0';
	const int MILITARY_TIME_WIDTH = 4;

	//Declaring time conversion constants
	const int STANDARD_MILITARY_TIME = 2400;
	const int PHILLY_TO_HONOLULU = 2400 - 600;
	const int PHILLY_TO_SEATTLE = 2400 - 300;
	const int PHILLY_TO_LONDON = 2400 + 500;
	const int PHILLY_TO_MOSCOW = 2400 + 800;
	const int PHILLY_TO_HONGKONG = 2400 + 1200;
	const int PHILLY_TO_AUCKLAND = 2400 + 1700;

	//Prompting the user for the time in Philadelphia and storing the time into memory
	int currentMilitaryTime = 0;
	cout << "What is the current time in Philadelphia? (Enter military time with no colon): ";
	cin >> currentMilitaryTime;

	//Converting the current time in Philadelphia to other city times
	int honoluluCurrentTime = (currentMilitaryTime + PHILLY_TO_HONOLULU) % STANDARD_MILITARY_TIME;
	int seattleCurrentTime = (currentMilitaryTime + PHILLY_TO_SEATTLE) % STANDARD_MILITARY_TIME;
	int londonCurrentTime = (currentMilitaryTime + PHILLY_TO_LONDON) % STANDARD_MILITARY_TIME;
	int moscowCurrentTime = (currentMilitaryTime + PHILLY_TO_MOSCOW) % STANDARD_MILITARY_TIME;
	int hongkongCurrentTime = (currentMilitaryTime + PHILLY_TO_HONGKONG) % STANDARD_MILITARY_TIME;
	int aucklandCurrentTime = (currentMilitaryTime + PHILLY_TO_AUCKLAND) % STANDARD_MILITARY_TIME;

	//outputting the times in other cities
	cout << "\nCurrent times in other cities" << endl;
	cout << "\nHonolulu: " << setfill(TIME_SPACE_FILL) << setw(MILITARY_TIME_WIDTH) << honoluluCurrentTime << endl;
	cout << "Seattle: " << setfill(TIME_SPACE_FILL) << setw(MILITARY_TIME_WIDTH) << seattleCurrentTime << endl;
	cout << "London: " << setfill(TIME_SPACE_FILL) << setw(MILITARY_TIME_WIDTH) << londonCurrentTime << endl;
	cout << "Moscow: " << setfill(TIME_SPACE_FILL) << setw(MILITARY_TIME_WIDTH) << moscowCurrentTime << endl;
	cout << "Hong Kong: " << setfill(TIME_SPACE_FILL) << setw(MILITARY_TIME_WIDTH) << hongkongCurrentTime << endl;
	cout << "Auckland: " << setfill(TIME_SPACE_FILL) << setw(MILITARY_TIME_WIDTH) << aucklandCurrentTime << endl;

	//Keeping the program from exiting too early
	int exitVaraible;
	cout << "\nEnter any key to exit: ";
	cin >> exitVaraible;

	return 0;
}