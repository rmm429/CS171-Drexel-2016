/*
Program: OzConverted.cpp
Purpose: To convert a user-inputted ounce amount into many other related amounts
Name: Ricky Mangerie
Last Date Revised: 1/19/2016
Contact: rmm429@drexel.edu
*/

//preprocessor
#include <iostream>
using namespace std;

int main()
{
	//Declaring conversion constants
	const double OZ_IN_TBSP = 0.5;
	const int OZ_IN_GILL = 4;
	const int OZ_IN_CUP = 8;
	const int OZ_IN_PINT = 16;
	const int OZ_IN_QRT = 32;
	const int OZ_IN_GAL = 128;
	const int OZ_IN_BRL = 5376;

	//Prompting the user to enter onces and storing their output into memory
	int oz = 0;
	cout << "How many fluid ounces do you have?  (Please enter an Integer amount): ";
	cin >> oz;

	//Declaring a remaining ounces variable
	int ozRem = 0;

	//Calculating how many barrels there are for the given ounces and storing remaining ounces into a variable
	int brl = oz / OZ_IN_BRL;
	ozRem = oz % OZ_IN_BRL;

	//Calculating how many gallons there are for the given ounces remainingand storing remaining ounces into a variable
	int gal = ozRem / OZ_IN_GAL;
	ozRem = ozRem % OZ_IN_GAL;

	//Calculating how many quarts there are for the given ounces remaining and storing remaining ounces into a variable
	int qrt = ozRem / OZ_IN_QRT;
	ozRem = ozRem % OZ_IN_QRT;

	//Calculating how many pints there are for the given ounces remaining and storing remaining ounces into a variable
	int pint = ozRem / OZ_IN_PINT;
	ozRem = ozRem % OZ_IN_PINT;

	//Calculating how many cups there are for the given ounces remaining and storing remaining ounces into a variable
	int cup = ozRem / OZ_IN_CUP;
	ozRem = ozRem % OZ_IN_CUP;

	//Calculating how many gills there are for the given ounces remaining and storing remaining ounces into a variable
	int gill = ozRem / OZ_IN_GILL;
	ozRem = ozRem % OZ_IN_GILL;

	//Calculating how many tablespoons there are for the given ounces remaining and storing remaining ounces into a variable
	int tbsp = ozRem / OZ_IN_TBSP;

	//Outputting the given ounces into the different conversion types
	cout << "\n" << oz << " fluid ounces can be divided into:" << endl;
	cout << brl << " barrel(s)" << endl;
	cout << gal << " gallon(s)" << endl;
	cout << qrt << " quart(s)" << endl;
	cout << pint << " pint(s)" << endl;
	cout << cup << " cup(s)" << endl;
	cout << gill << " gill(s)" << endl;
	cout << tbsp << " tablespoons" << endl;

	//Making sure the program console does not exit too early
	int exitVariable;
	cout << "\nType any key to exit: ";
	cin >> exitVariable;

	return 0;
}