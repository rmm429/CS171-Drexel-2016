/*
Program: ZipToBar.cpp
Purpose: To produce a valid bar code given a five digit zip code
Author: Ricky Mangerie
Last Date Revised: 2/11/2016
Contact: rmm429@drexel.edu
*/

//Preprocessor
#include <iostream>
#include <string> //allows the program to return and print string values
using namespace std;

//Global constants
const string HALFBAR = ":";
const string FULLBAR = "|";
const int FIRST_DIGIT_COMPUTATION = 10000;
const int SECOND_DIGIT_COMPUTATION = 1000;
const int THIRD_DIGIT_COMPUTATION = 100;
const int FOURTH_DIGIT_COMPUTATION = 10;

int makeCheckDigit(int zipcode);
/*
	Computes the check digit of a barcode

	@param zipcode - the zip code that will be used in creating the check digit

	@return checkDigit - returns the check digit calculated from the zipcode

	NOTES: Must use a positive integer value of one digit to five digits

		   The program will read zip codes with one digit 
		   to four digits as a five digit zip code with zeros 
		   preceeding the digits entered (ex. 12 = 00012)

	PROGRAMMER: Ricky Mangerie
*/

string convertDigit(int value);
/*
	Computes the bar code version of an integer value

	@param value - an integer value

	@return barCode - returns the bar code version of the integer value

	REQUIREMENTS: #include <string>

	NOTES: Must use a postivie integer between 0 and 9

	PROGRAMMER: Ricky Mangerie
*/

string barcode(int zipcode);
/*
	Computes the full bar code of a given zip code

	@param zipcode - the zip code that will be converted into a bar code

	@return barCode - returns the full barcode of a given zipcode

	REQUIREMENTS: #include <string>

	NOTES: Must use a positive integer value of one digit to five digits

		   The program will read zip codes with one digit 
		   to four digits as a five digit zip code with zeros 
		   preceeding the digits entered (ex. 12 = 00012)

	PROGRAMMER: Ricky Mangerie
*/

int main()
{
	//Local variables
	int zipCode = 0;
	string barCode;
	const int FIVE_DIGIT_MAX = 9;

	//Error control loop
	do
	{
		//Retreving a zip code
		cout << "Enter a zip code: ";
		cin >> zipCode;

		//Producing errors for invalid zip code values
		if (zipCode < 0)
		{
			cout << "\nEnter a non-negative number!" << endl;
		}
		else if ((zipCode / FIRST_DIGIT_COMPUTATION) > FIVE_DIGIT_MAX)
		{
			cout << "\nEnter a five-digit zip code!" << endl;
		}
		//Sending the zip code value to the function barCode()
		else
		{
			barCode = barcode(zipCode);
			cout << "\nThe bar code for the given zip code is: " << barCode << endl;
		}
	} while (zipCode < 0 || (zipCode / FIRST_DIGIT_COMPUTATION) > FIVE_DIGIT_MAX); //If the zip code is a negative number or greater than five digits, keep doing error control
	
	//Ensuring the program does not exit prematurely
	int dummyVar;
	cout << "\nEnter any key to exit: ";
	cin >> dummyVar;
}

//--Converts a zip code into a bar code

string barcode(int zipcode)
{
	//Local variables
	string barCode;
	int remainingDigits = 0;

	//Calculating the check digit by sending the zip code to the function makeCheckDigit()
	int checkDigit = makeCheckDigit(zipcode);
	
	//Retrieving each digit of the zip code individually
	int firstDigit = (zipcode / FIRST_DIGIT_COMPUTATION);
	remainingDigits = (zipcode % FIRST_DIGIT_COMPUTATION);
	int secondDigit = (remainingDigits / SECOND_DIGIT_COMPUTATION);
	remainingDigits = (remainingDigits % SECOND_DIGIT_COMPUTATION);
	int thirdDigit = (remainingDigits / THIRD_DIGIT_COMPUTATION);
	remainingDigits = (remainingDigits % THIRD_DIGIT_COMPUTATION);
	int fourthDigit = (remainingDigits / FOURTH_DIGIT_COMPUTATION);
	remainingDigits = (remainingDigits % FOURTH_DIGIT_COMPUTATION);
	int fifthDigit = remainingDigits;

	//Converting each digit to its bar code counterpart by sending each digit to the function convertDigit()
	barCode = FULLBAR;
	barCode += convertDigit(firstDigit);
	barCode += convertDigit(secondDigit);
	barCode += convertDigit(thirdDigit);
	barCode += convertDigit(fourthDigit);
	barCode += convertDigit(fifthDigit);
	barCode += convertDigit(checkDigit);
	barCode += FULLBAR;

	//Returning the full bar code
	return barCode;

}

//--Computes the check digit of a zip code

int makeCheckDigit(int zipcode)
{
	//Local variables
	int remainingDigits = 0;
	int sumOfDigits = 0;
	int temporaryCheckDigit = 0;
	int checkDigit = 0;
	int ZERO_TO_NINE_CHECK = 10;

	//Retrieving each digit of the zip code individually
	int firstDigit = (zipcode / FIRST_DIGIT_COMPUTATION);
	remainingDigits = (zipcode % FIRST_DIGIT_COMPUTATION);
	int secondDigit = (remainingDigits / SECOND_DIGIT_COMPUTATION);
	remainingDigits = (remainingDigits % SECOND_DIGIT_COMPUTATION);
	int thirdDigit = (remainingDigits / THIRD_DIGIT_COMPUTATION);
	remainingDigits = (remainingDigits % THIRD_DIGIT_COMPUTATION);
	int fourthDigit = (remainingDigits / FOURTH_DIGIT_COMPUTATION);
	remainingDigits = (remainingDigits % FOURTH_DIGIT_COMPUTATION);
	int fifthDigit = remainingDigits;
	sumOfDigits = firstDigit + secondDigit + thirdDigit + fourthDigit + fifthDigit;
	
	//Calculating the check digit
	temporaryCheckDigit = ZERO_TO_NINE_CHECK - (sumOfDigits % ZERO_TO_NINE_CHECK);

	//Error check and setting the final check digit
	if ((temporaryCheckDigit % ZERO_TO_NINE_CHECK) == 0) //If the sum of the zip code is zero or the check digit is already a multiple of 10, set the check digit equal to 0
	{
		
		checkDigit = 0;
	}
	else if (temporaryCheckDigit < 0)
	{
		checkDigit = -temporaryCheckDigit;
	}
	else
	{
		checkDigit = temporaryCheckDigit;
	}

	//Returning the check digit
	return checkDigit;
}

//--Computes the bar code counterpart of a given integer value

string convertDigit(int value)
{
	//Local variables
	string barCode;

	if (value == 0)
	{
		//Converting the integer value 0 to its bar code counterpart
		barCode = FULLBAR + FULLBAR + HALFBAR + HALFBAR + HALFBAR;
	}
	else if (value == 1)
	{
		//Converting the integer value 1 to its bar code counterpart
		barCode = HALFBAR + HALFBAR + HALFBAR + FULLBAR + FULLBAR;
	}
	else if (value == 2)
	{
		//Converting the integer value 2 to its bar code counterpart
		barCode = HALFBAR + HALFBAR + FULLBAR + HALFBAR + FULLBAR;
	}
	else if (value == 3)
	{
		//Converting the integer value 3 to its bar code counterpart
		barCode = HALFBAR + HALFBAR + FULLBAR + FULLBAR + HALFBAR;
	}
	else if (value == 4)
	{
		//Converting the integer value 4 to its bar code counterpart
		barCode = HALFBAR + FULLBAR + HALFBAR + HALFBAR + FULLBAR;
	}
	else if (value == 5)
	{
		//Converting the integer value 5 to its bar code counterpart
		barCode = HALFBAR + FULLBAR + HALFBAR + FULLBAR + HALFBAR;
	}
	else if (value == 6)
	{
		//Converting the integer value 6 to its bar code counterpart
		barCode = HALFBAR + FULLBAR + FULLBAR + HALFBAR + HALFBAR;
	}
	else if (value == 7)
	{
		//Converting the integer value 7 to its bar code counterpart
		barCode = FULLBAR + HALFBAR + HALFBAR + HALFBAR + FULLBAR;
	}
	else if (value == 8)
	{
		//Converting the integer value 8 to its bar code counterpart
		barCode = FULLBAR + HALFBAR + HALFBAR + FULLBAR + HALFBAR;
	}
	else if (value == 9)
	{
		//Converting the integer value 9 to its bar code counterpart
		barCode = FULLBAR + HALFBAR + FULLBAR + HALFBAR + HALFBAR;
	}

	//returning the bar code value for the given integer value
	return barCode;
}

