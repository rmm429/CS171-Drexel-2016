/*
Program: BAC.cpp
Purpose: To provide BAC information given personal specified attributes
Author: Ricky Mangerie
Last Date Revised: 2/16/2016
Contact: rmm429@drexel.edu
*/

//preprocessor
#include <iostream>
#include <string> //allows strings to be outputted
#include <iomanip> //allows formatting of the output
using namespace std;

//global constants
const int CHAR_M = 77;
const int CHAR_F = 70;

//function prototypes
void computeBloodAlcoholConcentration(int numDrinks, int weight, int duration, double &maleBAC, double &femaleBAC);
/*
	Computes the BAC of a male and female under specified conditions

	@param numDrinks - the number of drinks consumed
	@param weight - the user's weight
	@param duration - the time since the last drink was consumed
	@param maleBAC - a reference parameter where the BAC of the male is stored
	@param femaleBAC - a reference parameter where the BAC of the female is stored

	NOTES: Must use a positive integer value between 0 and 1000 for weight
	       Must use a positive integer value between 0 and 1440 for duration
		   
	PROGRAMMER: Ricky Mangerie
*/

string impairment(double bac);
/*
	Assigns and returns a pre-defined message according to the inputted BAC

	@param bac - the calculated BAC

	@return impair - the impairment message associated with the BAC
	
	NOTES: The BAC must be a postive integer value

	PROGRAMMER: Ricky Mangerie
*/

int promptForInteger(string const &message, int lower, int upper);
/*
	Determines the validity of an inputted integer

	@param message - a reference parameter where a message prompting user input is contained
	@param lower - the lower boundary that the user input can not surpass
	@param upper - the upper boundary that the user input can not surpass

	@return num - the user-inputted numerical integer once it passes validity testing

	NOTES: The values for upper and lower are defined by the programmer
		   The message varies depending on what information the programmer wants from the user

	PROGRAMMER: Ricky Mangerie
*/
char promptForMorF(string const &message);
/*
	Determines the user's gender

	@param message - a reference parameter where a message prompting user input is contained

	@return gender - the current gender of the user

	REQUIREMENTS: #include <string>
	
	NOTES: The gender must be either the character 'M' or the character 'F'

	PROGRAMMER: Ricky Mangerie
*/

void showImpairmentChart(int weight, int duration, bool isMale);
/*
	Formulates the entire table for BAC infomrmation

	@param weight - the user's weight
	@param duration - the time since the last drink was consumed
	@param isMale - a boolean that is true if the user entered they were a male, false if female

	REQUIREMENTS: #include <iomanip>

	NOTES: Must use a positive integer value between 0 and 1000 for weight
		   Must use a positive integer value between 0 and 1440 for duration

	PROGRAMMER: Ricky Mangerie
*/

int main()
{
	//local variables
	int weight = 0;
	int duration = 0;
	char gender;
	bool isMale;
	string message = "";
	double maleBAC = 0.0;
	double femaleBAC = 0.0;

	//local constants
	const int WEIGHT_LOWER_BOUND = 0;
	const int WEIGHT_UPPER_BOUND = 1000;
	const int DURATION_LOWER_BOUND = 0;
	const int DURATION_UPPER_BOUND = 1440;

	//setting weight-prompting message and error checking the user-inputted weight
	message = "Enter your weight: ";
	weight = promptForInteger(message, WEIGHT_LOWER_BOUND, WEIGHT_UPPER_BOUND);

	//setting duration-prompting message and error checking the user-inputted duration
	message = "How many minutes has it been since your last drink: ";
	duration = promptForInteger(message, DURATION_LOWER_BOUND, DURATION_UPPER_BOUND);

	//setting message and error checking the user-inputted gender according to that message
	message = "Enter your sex as M or F: ";
	gender = promptForMorF(message);

	//checking to see if the gender is male or female
	if (gender == CHAR_M)
	{
		isMale = true;
	}
	else
	{
		isMale = false;
	}

	//calling the function showImpairmentChart
	showImpairmentChart(weight, duration, isMale);
}

//--determining the BAC for a male and female under specified conditions
void computeBloodAlcoholConcentration(int numDrinks, int weight, int duration, double &maleBAC, double &femaleBAC)
{
	//local constants
	const double MALE_CONSTANT = 3.8;
	const double FEMALE_CONSTANT = 4.5;
	const double SUBTRACTION_TIME = 40.0;
	const double SUBTRACTION_FACTOR = 0.01;
	
	//calculating the subtraction factor
	double durationSubtraction = (duration / SUBTRACTION_TIME) * SUBTRACTION_FACTOR; //determined by taking the duration since last drink and dividing it by 40 minutes, which is multiplied by 0.01 (the subtraction factor)

	//determining the BAC for males
	maleBAC = (double)numDrinks / weight * MALE_CONSTANT - durationSubtraction;

	//error checking
	if (maleBAC < 0)
	{
		
		maleBAC = 0.0;
	}

	//determining the BAC for females
	femaleBAC = (double)numDrinks / weight * FEMALE_CONSTANT - durationSubtraction;

	//error checking
	if (femaleBAC < 0)
	{
		
		femaleBAC = 0.0;
	}
}

//--determining the imapriment message given the BAC
string impairment(double bac)
{
	//local constants
	const double SAFE_LEVEL = 0.00;
	const double SOME_IMPAIRMENT = 0.04;
	const double SIGNIFICANT_AFFECTED = 0.08;
	const double SOME_CRIMINAL_PENALTIES = 0.10;
	const double DEATH_POSSIBLE = 0.30;
	const string SAFE = "Safe To Drive";
	const string SOMEIMPAIR = "Some Impairment";
	const string SIGNIFICANT = "Driving Skills Significantly Affected";
	const string MOST_STATES = "Criminal Penalties in Most US States";
	const string ALL_STATES = "Legally Intoxicated - Criminal Penalties in All US States";
	const string YOURE_DEAD = "Death is Possible!";

	//local variable
	string impair = "";

	//setting impair to the message if the BAC is less than or equal to 0.00
	if (bac <= SAFE_LEVEL)
	{
		impair = SAFE;
	}
	//setting impair to the impairment message for BAC levels between 0.00 and 0.04
	else if (bac > SAFE_LEVEL && bac <= SOME_IMPAIRMENT)
	{
		impair = SOMEIMPAIR;
	}
	//setting impair to the impairment message for BAC levels between 0.04 and 0.08
	else if (bac > SOME_IMPAIRMENT && bac <= SIGNIFICANT_AFFECTED)
	{
		impair = SIGNIFICANT;
	}
	//setting impair to the impairment message for BAC levels between 0.08 and 0.1
	else if (bac > SIGNIFICANT_AFFECTED && bac <= SOME_CRIMINAL_PENALTIES)
	{
		impair = MOST_STATES;
	}
	//setting impair to the impairment message for BAC levels between 0.1 and 0.3
	else if (bac > SOME_CRIMINAL_PENALTIES && bac <= DEATH_POSSIBLE)
	{
		impair = ALL_STATES;
	}
	//setting impair to the impairment message for BAC levels of 0.3 and above
	else if (bac > DEATH_POSSIBLE)
	{
		impair = YOURE_DEAD;
	}

	//returning the impairment message
	return impair;
}

//--Checking to make sure integer values are correct
int promptForInteger(string const &message, int lower, int upper)
{
	//local variable
	int num = 0;
	
	//Keep prompting until correct input is received
	do
	{
		//prompt the pre-defined message and save input
		cout << message;
		cin >> num;
		if (num < lower || num > upper)
		{
			//Print error message if inputted number is outside of boundaries
			cout << "\nPlease enter a correct number!" << endl;
		}
		else
		{
			//Returning inputted number if passes error checks
			return num;
		}
	}while (num < lower || num > upper);
}

//--Getting gender information from the user
char promptForMorF(string const &message)
{
	//local variable
	char gender;
	
	//keep prompting until correct input is received
	do
	{
		//prompt the pre-defined message and save input
		cout << message;
		cin >> gender;
		if (gender == CHAR_M || gender == CHAR_F)
		{
			//return gender if input is either 'M' or 'F'
			return gender;
		}
		else
		{
			//Print error message if input is not either 'M' or 'F'
			cout << "\nPlease enter either M or F!" << endl;
		}
	}while(gender != CHAR_M || gender != CHAR_F);
}

//--Finalizing and printing out the impairment chart
void showImpairmentChart(int weight, int duration, bool isMale)
{
	//local constants
	const int RIGHT_CUSHION = 11;
	const int DECIMAL_PRECISION = 3;

	//local variables
	int numDrinks = 0;
	string gender;
	double maleBAC = 0.0;
	double femaleBAC = 0.0;
	
	//Determining the gender entered
	if (isMale == true)
	{
		gender = "male";
	}
	else
	{
		gender = "female";
	}

	//Printing out the weight and gender
	cout << weight << " pounds, " << gender << endl;

	//Printing out the header for the chart
	cout << "# of Drinks \t BAC \t Message" << endl;

	//loop that prints out BACs for 0 drinks to 10 drinks
	do
	{
		//Computing the BAC from the user-inputted information
		computeBloodAlcoholConcentration(numDrinks, weight, duration, maleBAC, femaleBAC);

		//Printing out specific information given the specified gender
		if (isMale == true)
		{
			//Printing out all information for the male BAC
			cout << setw(RIGHT_CUSHION) << right << numDrinks << "\t " << fixed << setprecision(DECIMAL_PRECISION) << maleBAC << "\t " << impairment(maleBAC) << endl;
		}
		else
		{
			//Printing out all information for the female BAC
			cout << setw(RIGHT_CUSHION) << right << numDrinks << "\t " << fixed << setprecision(DECIMAL_PRECISION) << femaleBAC << "\t " << impairment(femaleBAC) << endl;
		}
		//Increasing the drink count by 1
		numDrinks++;
	} while (numDrinks <= 10);
}
