/*
Program: Deal.cpp
Purpose: To provide statistical analysis to switching and keeping the door for the game "Let's Make a Deal"
Author: Ricky Mangerie
Last Date Revised: 3/1/2016
Contact: rmm429@drexel.edu
*/
#include <iostream>
#include <iomanip> //Allows access to output manipulation
using namespace std;

void changeSeed(int randomSeed);
/*
	Changes the random number seed and assists in generating different random numbers

	@param randonSeed - the number in which the random number will be seeded by (does not have much physical meaning)

	NOTES: Must use a positive integer value

	PROGRAMMER: Ricky Mangerie
*/

void setupDoors(char &door1, char &door2, char &door3);
/*
	Sets which doors have the goats and which door has the car

	@param door1 - a reference parameter that contains the value of what is behind door number one
	@param door2 - a reference parameter that contains the value of what is behind door number two
	@param door3 - a reference parameter that contains the value of what is behind door number three

	NOTES: The doors must contain either "C" or "G"

	PROGRAMMER: Ricky Mangerie
*/

void pickDoorChoices(char door1, char door2, char door3, int &doorPlayer, int &doorMonty);
/*
	Determines which door has the car behind it, which door the player has chosen, and which door "Monty" will reveal

	@param door1 - a reference parameter that contains the value of what is behind door number one
	@param door2 - a reference parameter that contains the value of what is behind door number two
	@param door3 - a reference parameter that contains the value of what is behind door number three
	@param doorPlayer - a reference parameter that contains a random number that signifies the player's door choice
	@param doorMonty - a reference parameter that contains which door "Monty" will display to the player

	NOTES: The doors must conain either "C" or "G"
		   doorPlayer and the car door must contain a random number between 1 and 3
		   doorMonty must contain a random number between 1 and 3 that must not equal the player's door or the door with the car

	PROGRAMMER: Ricky Mangerie
*/

int decideUnchosenDoor(int &doorPlayer, int &doorMonty);
/*
	Calculates which door was the door that the player did not choose and that "Monty" did not choose

	@param doorPlayer - a reference parameter that contains a random number that signifies the player's door choice
	@param doorMonty - a reference parameter that contains which door "Monty" will display to the player

	@return doorUnchosen - an integer that contains the door number that was not chosen

	NOTES: doorPlayer must conatain a random number between 1 and 3
		   doorMonty must contain a random number between 1 and 3 and must not equal the player's door or the door with the car
		   doorUnchosen  must contain a number between 1 and 3 that is neither the value of doorPlayer nor the value of doorMonty

	PROGRAMMER: Ricky Mangerie
*/

void changeDoor(double doorUnchosen, double &switchWins, double &switchDoesNotWin);
/*
	Determines how often the player wins when they opted to switch the door rather than keep the door that they chose

	@param doorUnchosen - an integer that contains the door number that was not chosen
	@param switchWins - a reference parameter that determines how often switching the door won the player a car
	@param switchDoesNotWin - a reference parameter that determines how often switching the door does not win the player a car

	NOTES: doorUnchosen  must contain a number between 1 and 3
		   switchWins and switchDoesNotWin must only be calculated using double variables
		   variables playerSwitchEqualsDoor and playerSwitchDoesNotEqualDoor must be static
	
	PROGRAMMER: Ricky Mangerie
*/

void keepDoor(double doorPlayer, double &keepWins, double &keepDoesNotWin);
/*
	Determines how often the player wins when they keep the door that they chose

	@param doorPlayer - an integer that contains a random number that signifies the player's door choice
	@param keepWins - a reference parameter that determines how often keeping the door won the player a car
	@param keepDoesNotWin - a reference parameter that determines how often keeping the door does not win the player a car

	NOTES: doorPlayer  must contain a number between 1 and 3
	       keepWins and keepDoesNotWin must only be calculated using double variables
		   variables playerKeepEqualsDoor and playerKeepDoesNotEqualDoor must be static

	PROGRAMMER: Ricky Mangerie
*/

void keepOrSwitchStrategy();
/*
	Calls the rest of the functions, determines the "keep or switch" statistics, and outputs the data cleanly

	NOTES: Must call all of the functions in the program except for the changeSeed() function
	       Must contain all of the variables that were used as reference parameters in the other functions

	REQUIREMENTS: #include <iomanip>

	PROGRAMMER: Ricky Mangerie
*/

//Global constants
const double TOTAL_RUNS = 10000.0;
const double DECIMAL_TO_PERCENTAGE = 100.0;
const double RANDOM_NUMBER_LIMIT = 3.0; //Ensures that the random number will be between 0 and 2
const double RANDOM_FUNCTIONALITY = 1.0; //Ensures that the random number generator works properly
const double ZERO_TO_ONE = 1.0; //Ensures that the random number will generate from 1 to 3 rather than 0 to 2

//Global variable
int doorCar = 0;

int main()
{
	//local variable
	int randomSeed;

	//Getting the random seed integer
	cout << "Enter a random number seed integer value: ";
	cin >> randomSeed;

	//Changing the random seed
	changeSeed(randomSeed);

	//Calling the keepOrSwitchStrategy() function
	keepOrSwitchStrategy();

	//Ensuring the program does not exit too early
	int d = 0;
	cout << "\nEnter any key to exit: ";
	cin >> d;
}

//--Changes the random number seed and assists in generating different random numbers
void changeSeed(int randomSeed)
{
	//Changing the random seed value
	srand((randomSeed)*(rand() / (RAND_MAX + RANDOM_FUNCTIONALITY)));
}

//--Sets which doors have the goats and which door has the car
void setupDoors(char &door1, char &door2, char &door3)
{
	//Local variable
	int randNum = 0;

	//A loop that ensures that the door choice is random
	for (int i = 0; i < TOTAL_RUNS; i++)
	{
		//Forming a random number between 0 and 2
		randNum = (RANDOM_NUMBER_LIMIT)*(rand() / (RAND_MAX + RANDOM_FUNCTIONALITY));

		//Setting the door values based on the random number
		switch (randNum)
		{
			case 0:
			{
				  door1 = 'C';
				  door2 = 'G';
				  door3 = 'G';
				  break;
			}
			case 1:
			{
				  door1 = 'G';
				  door2 = 'C';
				  door3 = 'G';
				  break;
			}
			case 2:
			{
				  door1 = 'G';
				  door2 = 'G';
				  door3 = 'C';
				  break;
			}
		}
	}
}

//--Determines which door has the car behind it, which door the player has chosen, and which door "Monty" will reveal
void pickDoorChoices(char door1, char door2, char door3, int &doorPlayer, int &doorMonty)
{
	//Randomly choosing which door the player will choose
	doorPlayer = (RANDOM_NUMBER_LIMIT)*(rand() / (RAND_MAX + RANDOM_FUNCTIONALITY)) + ZERO_TO_ONE;

	//Evaluating which door has the car behind it
	if (door1 == 'C')
	{
		doorCar = 1;
	}
	else if (door2 == 'C')
	{
		doorCar = 2;
	}
	else if (door3 == 'C')
	{
		doorCar = 3;
	}

	//Choosing which door "Monty" will reveal to the player
	do
	{
		doorMonty = (RANDOM_NUMBER_LIMIT)*(rand() / (RAND_MAX + RANDOM_FUNCTIONALITY)) + ZERO_TO_ONE;
	}while (doorMonty == doorPlayer || doorMonty == doorCar);
}

//--Calculates which door was the door that the player did not choose and that "Monty" did not choose
int decideUnchosenDoor(int &doorPlayer, int &doorMonty)
{
	//Local variable
	int doorUnchosen;

	//Calculating which door is the unchosen door
	if ((doorPlayer == 1 || doorMonty == 1) && (doorMonty == 2 || doorPlayer == 2))
	{
		doorUnchosen = 3;
	}
	else if ((doorPlayer == 1 || doorMonty == 1) && (doorMonty == 3 || doorPlayer == 3))
	{
		doorUnchosen = 2;
	}
	else if ((doorPlayer == 2 || doorMonty == 2) && (doorMonty == 3 || doorPlayer == 3))
	{
		doorUnchosen = 1;
	}

	//Returning the unchosen door value
	return doorUnchosen;
}

//--Determines how often the player wins when they opted to switch the door rather than keep the door that they chose
void changeDoor(double doorUnchosen, double &switchWins, double &switchDoesNotWin)
{
	//Local static variables
	static double playerSwitchEqualsDoor = 0;
	static double playerSwitchDoesNotEqualDoor = 0;

	//Simulating that the player is switching their door
	int doorPlayer = doorUnchosen;

	//If the player won...
	if (doorPlayer == doorCar)
	{
		//Increase the total number of times that the player won
		playerSwitchEqualsDoor++;
	}
	//If the player lost...
	else
	{
		//Increase the total number of times that the player lost
		playerSwitchDoesNotEqualDoor++;
	}

	//Determine the percentage of times that the player won by swtiching doors
	switchWins = (playerSwitchEqualsDoor / TOTAL_RUNS) * DECIMAL_TO_PERCENTAGE;

	//Determine the percentage of times that the player lost by switching doors
	switchDoesNotWin = (playerSwitchDoesNotEqualDoor / TOTAL_RUNS) * DECIMAL_TO_PERCENTAGE;
}

//--Determines how often the player wins when they keep the door that they chose
void keepDoor(double doorPlayer, double &keepWins, double &keepDoesNotWin)
{
	//Local static variables
	static double playerKeepEqualsDoor = 0;
	static double playerKeepDoesNotEqualDoor = 0;

	//If the player won...
	if (doorPlayer == doorCar)
	{
		//Increase the total number of times that the player won
		playerKeepEqualsDoor++;
	}
	//If the player lost...
	else
	{
		//Increase the total number of times that the player lost
		playerKeepDoesNotEqualDoor++;
	}

	//Determine the percentage of times that the player won by keeping the door
	keepWins = (playerKeepEqualsDoor / TOTAL_RUNS) * DECIMAL_TO_PERCENTAGE;

	//Determine the percentage of times that the player lost by keeping the door
	keepDoesNotWin = (playerKeepDoesNotEqualDoor / TOTAL_RUNS) * DECIMAL_TO_PERCENTAGE;

}

//--Calls the rest of the functions, determines the "keep or switch" statistics, and outputs the data cleanly
void keepOrSwitchStrategy()
{
	//Local variables
	char door1;
	char door2;
	char door3;
	int doorPlayer;
	int doorMonty;
	int doorUnchosen;
	double switchWins;
	double switchDoesNotWin;
	double keepWins;
	double keepDoesNotWin;

	//Local constant
	const int RATIO_TOTAL = 10;
	const int DECIMAL_ROUNDING = 2;

	//Running each function 10,000 times to get a fair percentage and ratio of wins and losses
	for (int i = 0; i < TOTAL_RUNS; i++)
	{
		//Placing goats and the car behind the three doors
		setupDoors(door1, door2, door3);
		//Choosing the player's door and "Monty's" door
		pickDoorChoices(door1, door2, door3, doorPlayer, doorMonty);
		//Calculating the unchosen door
		doorUnchosen = decideUnchosenDoor(doorPlayer, doorMonty);

		//Calculating the wins and losses percentage when switching doors
		changeDoor(doorUnchosen, switchWins, switchDoesNotWin);
		//Calculating the wins and lossess percentage when keeping doors
		keepDoor(doorPlayer, keepWins, keepDoesNotWin);
	}

	//Creating ratio variables
	int ratioWinsSwitch = (switchWins / RATIO_TOTAL);
	int ratioWinsKeep = (keepWins / RATIO_TOTAL);

	//Outputting the data
	cout << "Whenever the player switched their door, after 10,000 runs, the player won " << fixed << setprecision(DECIMAL_ROUNDING) << switchWins << "% of the time and lost " << fixed << setprecision(DECIMAL_ROUNDING) << switchDoesNotWin << "% of the time." << endl;
	cout << "General ratio of wins when switching doors (wins : total): " << ratioWinsSwitch << " : " << RATIO_TOTAL << endl;
	cout << "Whenever the player kept their door, after 10,000 runs, the player won " << fixed << setprecision(DECIMAL_ROUNDING) << keepWins << "% of the time and lost " << fixed << setprecision(DECIMAL_ROUNDING) << keepDoesNotWin << "% of the time." << endl;
	cout << "General ratio of wins when keeping doors (wins : total): " << ratioWinsKeep << " : " << RATIO_TOTAL << endl;

}

